package formats;

public interface FormatWriter {
	public void write(KV record);
}
