Ajouter les fichiers de configurations et d'initialisation de la plateforme.
